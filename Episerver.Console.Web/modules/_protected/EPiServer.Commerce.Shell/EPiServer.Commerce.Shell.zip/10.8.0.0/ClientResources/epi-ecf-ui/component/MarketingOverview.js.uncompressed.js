require({cache:{
'url:epi-ecf-ui/component/templates/MarketingOverview.html':"<div>\r\n\t<div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"epi-ecf-ui/widget/MarketingToolbar\" class=\"epi-viewHeaderContainer epi-localToolbar clearfix\"></div>\r\n    <div data-dojo-attach-point=\"leftPaneContainer\"></div>\r\n    <div data-dojo-type=\"epi-ecf-ui/widget/CampaignItemList\" data-dojo-attach-point=\"campaignItemList\"></div>\r\n</div>"}});
define("epi-ecf-ui/component/MarketingOverview", [
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/dom-geometry",
    "dojo/when",
// dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/layout/_LayoutWidget",
// epi
    "epi/shell/_ContextMixin",

    "../widget/FacetGroupList",
    "../widget/viewmodel/MarketingFacetGroupViewModel",
    "../widget/viewmodel/MarketingFacetGroupListViewModel",
// resources
    "dojo/text!./templates/MarketingOverview.html",
// Widgets in the template
    "../widget/CampaignItemList",
    "../widget/MarketingToolbar"
], function (
    declare,
    lang,

    domGeometry,
    when,
// dijit
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    _LayoutWidget,
// epi
    _ContextMixin,

    FacetGroupList,
    MarketingFacetGroupViewModel,
    MarketingFacetGroupListViewModel,
// resources
    template
) {

    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ContextMixin], {
        // summary:
        //      This is the initializer of Marketing Overview.

        templateString: template,

        postCreate: function () {
            this.inherited(arguments);

            var campaignFacetSettings = {
                itemViewModelClass: MarketingFacetGroupViewModel,
                listViewModelClass: MarketingFacetGroupListViewModel
            };
            this._campaignFacet = this._campaignFacet || new FacetGroupList(campaignFacetSettings);
            this.own(this._campaignFacet);

            this._campaignFacet.placeAt(this.leftPaneContainer);
        },

        updateView: function (data, context) {
            // summary:
            //      Updates the view, to reflect data changes.(when opening this view second time)
            // tags:
            //      protected

            this.toolbar.update({
                currentContext: context,
                viewConfigurations: {
                    availableViews: data.availableViews,
                    viewName: data.viewName
                }
            });
        },

        layout: function () {
            // summary:
            //      Layout the children widgets.
            // tags:
            //      protected

            this.inherited(arguments);

            var toolbarSize = domGeometry.getMarginBox(this.toolbar.domNode);
            var facetSize = domGeometry.getMarginBox(this._campaignFacet.domNode);

            var contentHeight = this._contentBox.h - toolbarSize.h;
            domGeometry.setMarginBox(this._campaignFacet.domNode, { h: contentHeight });

            // Set the size of the marketing overview to be the content height minus the toolbar height and width minus the facet width.
            this.campaignItemList.resize({
                h: contentHeight,
                w: this._contentBox.w - facetSize.w
            });
        },

        startup: function () {
            this.inherited(arguments);
            when(this.getCurrentContext(), lang.hitch(this, this.contextChanged));
            this.toolbar.setViewSelectorVisible(true);
        },

        contextChanged: function (ctx, callerData) {
            this.toolbar.update({
                currentContext: ctx
            });
        }

    });

});