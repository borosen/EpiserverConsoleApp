require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/DictionaryItemEditor.html':"﻿<div>\r\n    <label for=\"value\">${resources.label.itemvalue}</label>\r\n    <div data-dojo-type=\"dijit/form/ValidationTextBox\"\r\n         data-dojo-attach-point=\"valueTextBox\" name=\"value\" required=\"true\" data-dojo-attach-event=\"onKeyDown: _handleKey\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/contentediting/editors/DictionaryItemEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/keys",
    // dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/ValidationTextBox",
    // epi
    "epi/dependency",
    // resources
    "dojo/text!./templates/DictionaryItemEditor.html",
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.dictionaryitemeditor"
], function(
    // dojo
    declare,
    keys,
    // dijit
    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    ValidationTextBox,
    // epi
    dependency,
    // resources
    template,
    resources
){
    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {

        templateString: template,

        resources: resources,

        store: null,

        dictionaryId: null,

        postCreate: function () {
            this.store = this.store || dependency.resolve("epi.storeregistry").get("epi.commerce.metadictionaryitem");
            this._setValidation();
        },

        saveToStore: function () {
            if (this.valueTextBox.validate()) {
                return this.store.put({
                    value: this.valueTextBox.value,
                    defaultValue: this.valueTextBox.value,
                    ownerMetaFieldId: this.dictionaryId
                });
            }
        },

        _handleKey: function(e){
            if(e.keyCode === keys.ENTER){
                this.executeDialog();
            } else if(e.keyCode === keys.ESCAPE){
                this.cancelDialog();
            }
        },

        _setValidation: function() {
            this.valueTextBox.set('pattern', '.{0,255}');
            this.valueTextBox.set('invalidMessage', this.valueTextBox.messages.rangeMessage);
        },

        executeDialog: function(){
            // empty function just to submit dialog on ENTER
        },

        cancelDialog: function(){
            // empty function just to cancel dialog on ESCAPE
        }
    });
});