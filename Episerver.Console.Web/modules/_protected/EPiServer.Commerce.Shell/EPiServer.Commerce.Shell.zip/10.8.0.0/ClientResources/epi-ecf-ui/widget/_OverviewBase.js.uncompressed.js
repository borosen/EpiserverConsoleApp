﻿define("epi-ecf-ui/widget/_OverviewBase", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-construct",
    "dojo/dom-geometry",
    "dojo/dom-style",
    "dojo/when",

// dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/layout/_LayoutWidget",

// epi
    "epi/dependency",
    "epi/shell/TypeDescriptorManager",
    "epi/shell/widget/_ModelBindingMixin",

// commerce
    "./BackToPreviousViewNotification",
    "../contentediting/ModelSupport"

], function (
// dojo
    declare,
    lang,
    domConstruct,
    domGeo,
    domStyle,
    when,

// dijit
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    _LayoutWidget,

// epi
    dependency,
    TypeDescriptorManager,
    _ModelBindingMixin,

// commerce
    BackToPreviousViewNotification,
    ModelSupport
) {

    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin], {
        // summary:
        //    Base class for the PricingOverview and InventoryOverview widgets
        // tags:
        //    protected

        postCreate: function () {
            this.inherited(arguments);

            if (!this.model && this.modelClassName) {
                var modelClass = declare(this.modelClassName);
                this.set("model", new modelClass());
            }

            if (!this._backToPreviousViewNotification) {
                this._backToPreviousViewNotification = new BackToPreviousViewNotification();
                this.own(
                    this._backToPreviousViewNotification.watch("notification", lang.hitch(this, this._defaultNotificationWatchHandler))
                );
            }
        },

        buildRendering: function () {
            this.inherited(arguments);
            if (!this.list) {
                this.list = this.list || new this.listType();
                this.own(this.list);
                domConstruct.place(this.list.domNode, this.listNode);
            }
            if (!this.metadata) {
                when(dependency.resolve("epi.shell.MetadataManager").getMetadataForType(this.metadataTypeName), lang.hitch(this, function (metadata) {
                    this.metadata = metadata;
                }));
            }
        },

        _setValueAttr: function (value) {
            // summary:
            //      Sets value for this widget.
            // value: content data
            //      Input content link to get data from.

            this.list.set("value", value.id);
            this._showNewItemView(false);

            //if the current content type has base type which is variation or package, then show add new item button
            if (TypeDescriptorManager.isBaseTypeIdentifier(value.dataType, ModelSupport.contentTypeIdentifier.variationContent) ||
                TypeDescriptorManager.isBaseTypeIdentifier(value.dataType, ModelSupport.contentTypeIdentifier.packageContent)) {
                domStyle.set(this.addNewItem.domNode, "display", "");
                this.model.set("value", value.id);
            }
            else {
                domStyle.set(this.addNewItem.domNode, "display", "none");
            }
        },

        showNotification: function () {
            // summary:
            //      Displays notification bar
            // tags:
            //      public
            this._backToPreviousViewNotification.showNotification();
        },

        _defaultNotificationWatchHandler: function (/*String*/name, /*Object*/oldValue, /*Object*/newValue) {
            // summary:
            //      Add/remove notification to/from notification bar
            // tags:
            //      private

            if (oldValue) {
                this.notificationBar.remove(oldValue);
            }

            if (newValue && newValue.content) {
                this.notificationBar.add(newValue);
            }

            this.layout();
        },

        layout: function () {
            // summary:
            //      Layout the overview editor.
            // tags:
            //      protected

            var headerSize = domGeo.getMarginBox(this.header);

            var height = this._contentBox.h - headerSize.h,
                width = this._contentBox.w;
            this.list.resize({
                h: height,
                w: width
            });
        },

        _onShowNewItem: function () {
            // summary:
            //      Add new item row to a variation/package.
            var newItem = this.model.getDefaultItem();
            this._showNewItemView(true);
            this.newItemWidget.set("value", newItem);
        },

        _onCancelNewItem: function () {
            this._showNewItemView(false);
        },

        _showNewItemNotification: function () {
            var notificationText = domConstruct.create("div", {
                innerHTML: this.resources.newitemnotification
            });
            this._backToPreviousViewNotification.set("notification", {
                content: notificationText,
                commands: [this._backToPreviousViewNotification.command]
            });
        },

        _createNewItemWidget: function () {
            this.newItemWidget = new this.newItemWidgetType({
                doLayout: false,
                metadata: this.metadata
            });
            this.newItemWidget.startup();
            this.own(this.newItemWidget);
            domConstruct.place(this.newItemWidget.domNode, this.newItemFormNode);
        }
    });
});
