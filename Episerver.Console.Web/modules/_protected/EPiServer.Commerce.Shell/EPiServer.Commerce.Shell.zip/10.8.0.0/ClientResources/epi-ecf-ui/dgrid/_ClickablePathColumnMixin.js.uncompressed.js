﻿define("epi-ecf-ui/dgrid/_ClickablePathColumnMixin", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/topic",
    "epi/shell/DestroyableByKey",
    "../contentediting/ModelSupport"
], function(
    declare,
    lang,
    aspect,
    topic,
    DestroyableByKey,
    ModelSupport
){
    return declare([DestroyableByKey], {

        postCreate: function(){
            this.inherited(arguments);
            this._setupClickablePathColumn();
        },

        _setupClickablePathColumn: function(){
            this.ownByKey("pathColumnClick", this.on(".dgrid-cell.dgrid-column-path:click", lang.hitch(this, this._publishContextRequestForPathClick)));
            for (var columnName in this.columns){
                if (columnName === "path"){
                    this.columns[columnName].className = "epi-ecf-uiPathLink";
                }
            }
        },

        _publishContextRequestForPathClick: function(event) {
            var row = this.row(event);
            var contentLink = row.data.family === ModelSupport.relationFamily.parents ? row.data.source : row.data.target;
            topic.publish("/epi/shell/context/request", { uri: "epi.cms.contentdata:///" + contentLink }, { sender: this });
        }
    });
});