﻿define("epi-cms/content-approval/ApprovalEnums", {
    // summary:
    //      A collection of enums reflecting the server side enums.
    // tags:
    //      internal

    definitionStatus: {
        enabled: 0,
        disabled: 1,
        inherited: 2
    },

    reviewerType: {
        user: 0,
        role: 1
    },

    status: {
        inReview: 0,
        approved: 1,
        rejected: 2
    }
});
